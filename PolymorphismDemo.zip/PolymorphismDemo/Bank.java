public  class Bank	{
	private String name;
	private String type;
	private int branchNo;
	
	public Bank(){};
	
	public Bank(String name, String type, int branchNo){
		this.name = name;
		this.type = type;
		this.branchNo = branchNo;
	}
	public String getName(){
        return name;
    }
    
    public String getType(){
        return type;
    }
    
    public int getBranchNo(){
        return branchNo;
    }
    
    public void info(){}
	
}