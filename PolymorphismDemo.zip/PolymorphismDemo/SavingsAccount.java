public class SavingsAccount extends Bank{
	private int accNo;
	public SavingsAccount(){
	}
	public SavingsAccount( String name, String type, int branchNo, int accNo){
		super(name,type,branchNo);
		this.accNo = accNo;
	}
	@Override
	public void info(){
			System.out.println("Savings Account Information:");
			System.out.println("Name is  " + getName());
			System.out.println("Type is " + getType());
			System.out.println("branchNo is " + getBranchNo());
			System.out.println("accNo is " + accNo);
	}
}
