public class BankingSector {
    private String secName;
    private Bank bank;

    
    public BankingSector() {
    }
    public BankingSector(String secName, Bank bank) {
        this.secName = secName;
        this.bank = bank;
    }

    public void setSector(Bank b) {
        this.bank = b;
    }

    public Bank getSector() {
        return bank;
    }

    public void all() {
        System.out.println("Banking Sector Name: " + secName);
        if (bank != null) {
            bank.info();
        } else {
            System.out.println("No bank associated with this sector.");
        }
    }
}
