public class FixedAccount extends Bank{
	private int count;
	public FixedAccount(){
	}
	public FixedAccount( String name, String type, int branchNo, int count){
		super(name,type,branchNo);
		this.count = count;
	}
	
	@Override
	public void info(){
			System.out.println("Fixed Account Information:");
			System.out.println("Bank name: " + getName());
			System.out.println("Account type: " + getType());
			System.out.println("branchNo: " + getBranchNo());
			System.out.println("Count " + count);
	}
}
