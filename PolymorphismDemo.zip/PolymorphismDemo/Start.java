public class Start {
    public static void main(String[] args) {
        FixedAccount fixedAcc = new FixedAccount("National Bank", "Fixed Deposit", 123, 5);
        
        SavingsAccount savingsAcc = new SavingsAccount("City Bank", "Savings", 456, 789012);
        
        BankingSector sector1 = new BankingSector("Investment Sector", fixedAcc);
        
        System.out.println("--- Demonstrating Fixed Account ---");
        fixedAcc.info();
        
        System.out.println("\n--- Demonstrating Savings Account ---");
        savingsAcc.info();
        
        System.out.println("\n--- Demonstrating Banking Sector with Fixed Account ---");
        sector1.all();
        
        System.out.println("\n--- Changing Banking Sector to Savings Account ---");
        sector1.setSector(savingsAcc);
        sector1.all();
        
        System.out.println("\n--- Getting Current Bank from Sector ---");
        Bank currentBank = sector1.getSector();
        if (currentBank != null) {
            currentBank.info();
        }
        
        BankingSector sector2 = new BankingSector();
        sector2.setSector(fixedAcc);
        System.out.println("\n--- Second Banking Sector ---");
        sector2.all();
    }
}