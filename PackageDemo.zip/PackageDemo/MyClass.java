package PackageDemo;   // declare package name

public class MyClass {
    private String message;

    // Constructor
    public MyClass(String msg) {
        this.message = msg;
    }

    // Method
    public void showMessage() {
        System.out.println("Message: " + message);
    }
}
