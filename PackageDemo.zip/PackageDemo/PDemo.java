import PackageDemo.MyClass;

public class PDemo {
    public static void main(String[] args) {
        MyClass obj = new MyClass("Hello from package PackageDemo!");
        obj.showMessage();
    }
}
